function gridLines(height, width) {
    const tableForm = document.getElementById("pixelCanvas");
    let grid = '';

    // loop go in each row
    for (let i = 0; i < height; i++) {
        grid += '<tr class="row-' + i + '">';
        //  loop go for each column
        for (let j = 0; j < width; j++) {
            grid += '<td class="cell" id="row-' + i + '_cell-' + j + '"></td>';
        }
        grid += '</tr>';
    }
    // it adds grid into tableform element
    tableForm.innerHTML = grid;

    // Add click event to grid cells whenever the table grid has been created
    addClickEventToCells();
}

//it get value for wiedth and height from user from gridLines()
function formSubmission() {
    event.preventDefault();
    const height = document.getElementById('inputHeight').value;
    const width = document.getElementById('inputWidth').value;
    gridLines(height, width);
}

//it add click events to all cells
function addClickEventToCells() {
    // on color selection return color:
    const colorPicker = document.getElementById("colorPicker");
    const cells = document.getElementsByClassName('cell');
    for (let i = 0; i < cells.length; i++) {
        cells[i].addEventListener("click", function (event) {
            let clickedCell = event.target;
            clickedCell.style.backgroundColor = colorPicker.value;
        });
    }
}



// when you submit sizePicker()
document.getElementById('sizePicker').onsubmit = function () {
    formSubmission();
};

//a default 11x11 grid.
gridLines(11, 11);
